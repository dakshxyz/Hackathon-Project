import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, ShoppingCart, Clock, User, ArrowLeft } from "lucide-react";
import type { FavoriteWithProduct } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import Navigation from "@/components/navigation";

export default function Favorites() {
  const { user } = useAuth();

  const { data: favorites = [], isLoading } = useQuery<FavoriteWithProduct[]>({
    queryKey: ['/api/favorites'],
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          <Heart className="h-16 w-16 mx-auto mb-6 text-muted-foreground" />
          <h1 className="text-2xl font-bold text-foreground mb-4">Sign in to view favorites</h1>
          <p className="text-muted-foreground mb-8">
            Create an account or sign in to save your favorite products.
          </p>
          <Link href="/login">
            <Button size="lg">Sign In</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Browse
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-foreground" data-testid="text-favorites-title">
              My Favorites
            </h1>
            <p className="text-muted-foreground">
              {favorites.length} item{favorites.length !== 1 ? 's' : ''} saved
            </p>
          </div>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-muted rounded-lg h-48 mb-3"></div>
                <div className="space-y-2 p-2">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                  <div className="h-5 bg-muted rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : favorites.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {favorites.map((favorite) => (
              <Card key={favorite.id} className="group hover:shadow-md transition-all duration-200 overflow-hidden">
                <CardContent className="p-0">
                  <div className="relative">
                    <Link href={`/product/${favorite.product.id}`}>
                      <div className="aspect-[4/3] bg-muted flex items-center justify-center overflow-hidden">
                        {favorite.product.image ? (
                          <img
                            src={favorite.product.image}
                            alt={favorite.product.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                        ) : (
                          <div className="text-muted-foreground">No image</div>
                        )}
                      </div>
                    </Link>
                    
                    <div className="absolute top-2 right-2">
                      <Heart className="h-5 w-5 fill-red-500 text-red-500" />
                    </div>
                  </div>
                  
                  <Link href={`/product/${favorite.product.id}`}>
                    <div className="p-4">
                      <Badge variant="secondary" className="mb-2 text-xs">
                        {favorite.product.category}
                      </Badge>
                      
                      <h3 className="font-semibold text-foreground line-clamp-2 mb-1" data-testid={`text-favorite-title-${favorite.product.id}`}>
                        {favorite.product.title}
                      </h3>
                      
                      <p className="text-lg font-bold text-primary mb-2" data-testid={`text-favorite-price-${favorite.product.id}`}>
                        ${favorite.product.price}
                      </p>
                      
                      <div className="flex items-center text-sm text-muted-foreground mb-2">
                        <User className="h-3 w-3 mr-1" />
                        <span>{favorite.product.owner.username}</span>
                      </div>
                      
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>Added {new Date(favorite.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
              <Heart className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No favorites yet</h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Start exploring and save products you love by clicking the heart icon.
            </p>
            <Link href="/">
              <Button size="lg" data-testid="button-browse-products">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Browse Products
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}