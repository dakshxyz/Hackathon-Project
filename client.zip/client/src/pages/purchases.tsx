import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ShoppingBag, 
  DollarSign, 
  Leaf, 
  Star, 
  Truck, 
  Clock,
  Eye,
  MessageCircle,
  RotateCcw,
  HelpCircle,
  ChevronDown,
  Package
} from "lucide-react";
import type { OrderWithItems } from "@shared/schema";
import { useState } from "react";

export default function Purchases() {
  const { user } = useAuth();
  const [timeFilter, setTimeFilter] = useState("all");

  const { data: orders = [], isLoading } = useQuery<OrderWithItems[]>({
    queryKey: ['/api/orders'],
    enabled: !!user?.id,
  });

  // Calculate statistics
  const stats = {
    totalOrders: orders.length,
    totalSpent: orders.reduce((sum, order) => sum + parseFloat(order.total), 0),
    co2Saved: (orders.length * 1.5).toFixed(1), // Estimate based on order count
    avgRating: "4.8", // Mock rating for demo
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'delivered':
        return <Badge className="bg-secondary/10 text-secondary">Delivered</Badge>;
      case 'pending':
        return <Badge className="bg-accent/10 text-accent-foreground">In Transit</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-muted rounded-xl h-24"></div>
            ))}
          </div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-muted rounded-xl h-48"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Purchase History</h1>
          <p className="text-muted-foreground mt-1">Track all your purchases</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={timeFilter} onValueChange={setTimeFilter}>
            <SelectTrigger className="w-[180px]" data-testid="select-time-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="6months">Last 6 months</SelectItem>
              <SelectItem value="year">This year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Purchase Statistics */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-sm">
          <CardContent className="p-6 text-center">
            <ShoppingBag className="h-6 w-6 text-primary mb-2 mx-auto" />
            <p className="text-2xl font-bold text-foreground" data-testid="stat-total-orders">
              {stats.totalOrders}
            </p>
            <p className="text-muted-foreground text-sm">Total Orders</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6 text-center">
            <DollarSign className="h-6 w-6 text-secondary mb-2 mx-auto" />
            <p className="text-2xl font-bold text-foreground" data-testid="stat-total-spent">
              ${stats.totalSpent.toFixed(0)}
            </p>
            <p className="text-muted-foreground text-sm">Total Spent</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6 text-center">
            <Star className="h-6 w-6 text-accent mb-2 mx-auto" />
            <p className="text-2xl font-bold text-foreground" data-testid="stat-avg-rating">
              {stats.avgRating}
            </p>
            <p className="text-muted-foreground text-sm">Avg Rating</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6 text-center">
            <Star className="h-6 w-6 text-accent mb-2 mx-auto" />
            <p className="text-2xl font-bold text-foreground" data-testid="stat-avg-rating">
              {stats.avgRating}
            </p>
            <p className="text-muted-foreground text-sm">Avg Rating</p>
          </CardContent>
        </Card>
      </div>

      {/* Orders List */}
      {orders.length > 0 ? (
        <div className="space-y-6">
          {orders.map((order) => (
            <Card key={order.id} className="shadow-sm overflow-hidden" data-testid={`order-${order.id}`}>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-4">
                  <div className="flex items-center space-x-4 mb-4 lg:mb-0">
                    <div>
                      <h3 className="font-semibold text-foreground" data-testid={`text-order-id-${order.id}`}>
                        Order #{order.id.slice(-8)}
                      </h3>
                      <p className="text-muted-foreground text-sm" data-testid={`text-order-date-${order.id}`}>
                        Ordered on {new Date(order.createdAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long', 
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-lg font-bold text-primary" data-testid={`text-order-total-${order.id}`}>
                      ${parseFloat(order.total).toFixed(2)}
                    </span>
                    {getStatusBadge(order.status || 'pending')}
                  </div>
                </div>

                {/* Order Items */}
                <div className="border-t border-border pt-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex items-center space-x-4 mb-4" data-testid={`order-item-${item.id}`}>
                      <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                        {item.product.image ? (
                          <img 
                            src={item.product.image} 
                            alt={item.product.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Package className="h-6 w-6 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground" data-testid={`text-item-title-${item.id}`}>
                          {item.product.title}
                        </h4>
                        <p className="text-muted-foreground text-sm">
                          Sold by {item.product.ownerId}
                        </p>
                        <div className="flex items-center space-x-3 mt-1">
                          <span className="text-sm text-muted-foreground">
                            Qty: <span data-testid={`text-item-quantity-${item.id}`}>{item.quantity}</span>
                          </span>
                          <span className="text-sm font-semibold text-primary" data-testid={`text-item-price-${item.id}`}>
                            ${parseFloat(item.price).toFixed(2)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Link href={`/product/${item.productId}`}>
                          <Button variant="ghost" size="sm" data-testid={`button-view-item-${item.id}`}>
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            // TODO: Implement review functionality
                          }}
                          data-testid={`button-review-item-${item.id}`}
                        >
                          <MessageCircle className="h-4 w-4 mr-1" />
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-4 border-t border-border">
                  <div className="flex items-center text-sm text-muted-foreground">
                    {order.status === 'delivered' ? (
                      <div className="flex items-center">
                        <Truck className="h-4 w-4 mr-2" />
                        <span>Delivered on {new Date(order.createdAt).toLocaleDateString()}</span>
                      </div>
                    ) : order.status === 'pending' ? (
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2 text-accent" />
                        <span>Expected delivery: {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <Package className="h-4 w-4 mr-2" />
                        <span>Order {order.status}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-3">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        // TODO: Implement order tracking
                      }}
                      data-testid={`button-track-order-${order.id}`}
                    >
                      Track Order
                    </Button>
                    {order.status === 'delivered' ? (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => {
                          // TODO: Implement buy again
                        }}
                        data-testid={`button-buy-again-${order.id}`}
                      >
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Buy Again
                      </Button>
                    ) : (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => {
                          // TODO: Implement order cancellation
                        }}
                        data-testid={`button-cancel-order-${order.id}`}
                      >
                        Cancel Order
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        // TODO: Implement help/support
                      }}
                      data-testid={`button-get-help-${order.id}`}
                    >
                      <HelpCircle className="h-4 w-4 mr-1" />
                      Get Help
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Load More Orders */}
          <div className="text-center mt-12">
            <Button 
              variant="secondary"
              onClick={() => {
                // TODO: Implement pagination
              }}
              data-testid="button-load-more-orders"
            >
              <ChevronDown className="h-4 w-4 mr-2" />
              Load Older Orders
            </Button>
          </div>
        </div>
      ) : (
        <div className="text-center py-16" data-testid="empty-purchases">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-muted text-muted-foreground rounded-xl mb-4">
            <ShoppingBag className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No purchases yet</h3>
          <p className="text-muted-foreground mb-6">Start your sustainable shopping journey today</p>
          <Link href="/feed">
            <Button data-testid="button-start-shopping">
              Browse Items
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
