import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Leaf, User, ShieldCheck, Heart, MapPin, Clock, Filter, SlidersHorizontal } from "lucide-react";
import type { ProductWithOwner } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// ProductCard component with favorites functionality
function ProductCard({ product }: { product: ProductWithOwner }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if product is favorited
  const { data: favoriteStatus = { isFavorite: false } } = useQuery<{ isFavorite: boolean }>({
    queryKey: ['/api/favorites', product.id],
    enabled: !!user && !!product.id,
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      if (favoriteStatus.isFavorite) {
        await apiRequest("DELETE", `/api/favorites/${product.id}`, {});
        return false;
      } else {
        await apiRequest("POST", "/api/favorites", { productId: product.id });
        return true;
      }
    },
    onSuccess: (newFavoriteState) => {
      queryClient.invalidateQueries({ queryKey: ['/api/favorites', product.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
      toast({
        title: newFavoriteState ? "Added to favorites!" : "Removed from favorites",
        description: newFavoriteState 
          ? "Product added to your favorites." 
          : "Product removed from your favorites.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="group hover:shadow-md transition-all duration-200 overflow-hidden">
      <CardContent className="p-0">
        <div className="relative">
          <Link href={`/product/${product.id}`}>
            <div className="aspect-[4/3] bg-muted flex items-center justify-center overflow-hidden">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
              ) : (
                <div className="text-muted-foreground">No image</div>
              )}
            </div>
          </Link>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="absolute top-2 right-2 bg-white/90 hover:bg-white backdrop-blur-sm"
            onClick={(e) => {
              e.preventDefault();
              toggleFavoriteMutation.mutate();
            }}
            disabled={!user || toggleFavoriteMutation.isPending}
            data-testid={`button-favorite-${product.id}`}
          >
            <Heart className={`h-4 w-4 ${favoriteStatus.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
          </Button>
        </div>
        
        <Link href={`/product/${product.id}`}>
          <div className="p-4">
            <Badge variant="secondary" className="mb-2 text-xs">
              {product.category}
            </Badge>
            
            <h3 className="font-semibold text-foreground line-clamp-2 mb-1" data-testid={`text-title-${product.id}`}>
              {product.title}
            </h3>
            
            <p className="text-lg font-bold text-primary mb-2" data-testid={`text-price-${product.id}`}>
              ${product.price}
            </p>
            
            <div className="flex items-center text-sm text-muted-foreground mb-2">
              <User className="h-3 w-3 mr-1" />
              <span>{product.owner.username}</span>
            </div>
            
            <div className="flex items-center text-xs text-muted-foreground">
              <Clock className="h-3 w-3 mr-1" />
              <span>{new Date(product.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </Link>
      </CardContent>
    </Card>
  );
}

export default function ProductFeed() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");

  const { data: products = [], isLoading } = useQuery<ProductWithOwner[]>({
    queryKey: ['/api/products', { search, category }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (category && category !== 'all') params.append('category', category);
      
      const response = await fetch(`/api/products?${params}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "Electronics", label: "Electronics" },
    { value: "Fashion", label: "Fashion" },
    { value: "Home & Garden", label: "Home & Garden" },
    { value: "Sports", label: "Sports" },
    { value: "Automotive", label: "Automotive" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Search Section */}
      <div className="bg-gradient-to-r from-primary to-secondary py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Buy & Sell Anything
            </h1>
            <p className="text-primary-foreground/90 text-lg">
              Find Great Deals Near You
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg p-2">
              <div className="flex flex-col md:flex-row gap-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    type="text"
                    placeholder="Search for products, brands and more..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10 border-0 focus-visible:ring-0 text-base h-12"
                    data-testid="input-search"
                  />
                </div>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="w-full md:w-[200px] h-12 border-0 focus:ring-0" data-testid="select-category">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button size="lg" className="h-12 px-8 bg-primary hover:bg-primary/90">
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Categories */}
      <div className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-foreground">Browse Categories</h2>
            <Link href="/add-product">
              <Button variant="outline" size="sm" data-testid="button-sell-item">
                <Plus className="h-4 w-4 mr-2" />
                Sell Now
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-2">
            <button
              onClick={() => setCategory("all")}
              className={`p-3 rounded-lg text-sm font-medium transition-colors ${
                category === "all"
                  ? 'bg-primary text-white'
                  : 'bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground'
              }`}
              data-testid="button-category-all"
            >
              All Categories
            </button>
            {categories.slice(1).map((cat) => (
              <button
                key={cat.value}
                onClick={() => setCategory(cat.value)}
                className={`p-3 rounded-lg text-sm font-medium transition-colors ${
                  category === cat.value
                    ? 'bg-primary text-white'
                    : 'bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`button-category-${cat.value.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-6">

        {/* Results Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-semibold text-foreground">
              {search || (category !== 'all') ? 'Search Results' : 'Latest Items'}
            </h2>
            {!isLoading && products.length > 0 && (
              <span className="text-sm text-muted-foreground">
                {products.length} item{products.length !== 1 ? 's' : ''} found
              </span>
            )}
          </div>
          <Button variant="outline" size="sm">
            <SlidersHorizontal className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        {/* Product Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-muted rounded-lg h-48 mb-3"></div>
                <div className="space-y-2 p-2">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                  <div className="h-5 bg-muted rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
              <Search className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No items found</h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              {search || (category !== 'all') 
                ? "Try adjusting your search terms or browse different categories" 
                : "Be the first to list an item in our marketplace"}
            </p>
            <Link href="/add-product">
              <Button size="lg" className="bg-primary hover:bg-primary/90" data-testid="button-add-first-item">
                <Plus className="h-5 w-5 mr-2" />
                Start Selling
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
