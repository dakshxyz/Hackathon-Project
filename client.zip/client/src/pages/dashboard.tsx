import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { User, Package, ShoppingBag, Star, Leaf } from "lucide-react";
import type { Product, OrderWithItems } from "@shared/schema";

const profileSchema = z.object({
  username: z.string().min(2, "Username must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  bio: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      username: user?.username || "",
      email: user?.email || "",
      bio: user?.bio || "",
    },
  });

  // Get user's products count
  const { data: userProducts = [] } = useQuery<Product[]>({
    queryKey: ['/api/user', user?.id, 'products'],
    enabled: !!user?.id,
  });

  // Get user's orders count  
  const { data: userOrders = [] } = useQuery<OrderWithItems[]>({
    queryKey: ['/api/orders'],
    enabled: !!user?.id,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const response = await apiRequest("PUT", `/api/user/${user?.id}`, data);
      return response.json();
    },
    onSuccess: (updatedUser) => {
      // Update auth context
      localStorage.setItem("user_data", JSON.stringify(updatedUser));
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update profile.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  const stats = [
    {
      title: "Active Listings",
      value: userProducts.filter(p => p.isActive).length,
      icon: Package,
      color: "text-primary",
    },
    {
      title: "Items Purchased", 
      value: userOrders.length,
      icon: ShoppingBag,
      color: "text-secondary",
    },
    {
      title: "Seller Rating",
      value: "4.8",
      icon: Star,
      color: "text-accent",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Card className="shadow-sm">
        <CardContent className="p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-20 h-20 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-2xl">
              <User className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground" data-testid="text-username">
                {user?.username}
              </h1>
              <p className="text-muted-foreground" data-testid="text-email">
                {user?.email}
              </p>
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-secondary/10 text-secondary mt-2">
                <Leaf className="h-3 w-3 mr-2" />
                Verified Seller
              </span>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className="bg-muted rounded-lg p-6 text-center">
                <stat.icon className={`h-6 w-6 mx-auto mb-2 ${stat.color}`} />
                <p className="text-2xl font-bold text-foreground" data-testid={`stat-${stat.title.toLowerCase().replace(' ', '-')}`}>
                  {stat.value}
                </p>
                <p className="text-muted-foreground text-sm">{stat.title}</p>
              </div>
            ))}
          </div>

          {/* Edit Profile Form */}
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Profile Information</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="username">Full Name</Label>
                <Input
                  id="username"
                  data-testid="input-edit-username"
                  {...form.register("username")}
                  className="mt-1"
                />
                {form.formState.errors.username && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.username.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  data-testid="input-edit-email"
                  {...form.register("email")}
                  className="mt-1"
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.email.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                rows={4}
                placeholder="Tell others about yourself and your sustainable living journey..."
                data-testid="input-edit-bio"
                {...form.register("bio")}
                className="mt-1"
              />
            </div>

            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={updateProfileMutation.isPending}
                data-testid="button-update-profile"
              >
                {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
