import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Minus, Plus, Trash2, ShoppingCart, Lock, ShieldCheck, Leaf, DollarSign } from "lucide-react";
import type { CartWithProduct } from "@shared/schema";
import { useLocation } from "wouter";

export default function Cart() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: cartItems = [], isLoading } = useQuery<CartWithProduct[]>({
    queryKey: ['/api/cart'],
    enabled: !!user?.id,
  });

  const updateQuantityMutation = useMutation({
    mutationFn: async ({ cartId, quantity }: { cartId: string; quantity: number }) => {
      const response = await apiRequest("PUT", `/api/cart/${cartId}`, { quantity });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update quantity",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: async (cartId: string) => {
      const response = await apiRequest("DELETE", `/api/cart/${cartId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Item removed",
        description: "Item has been removed from your cart.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove item",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const checkoutMutation = useMutation({
    mutationFn: async (total: number) => {
      const response = await apiRequest("POST", "/api/orders", { total: total.toString() });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      toast({
        title: "Order placed successfully!",
        description: "Check your email for order confirmation.",
      });
      setLocation("/purchases");
    },
    onError: (error: any) => {
      toast({
        title: "Checkout failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const subtotal = cartItems.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + tax;

  const handleQuantityChange = (cartId: string, quantity: number) => {
    if (quantity < 1) return;
    updateQuantityMutation.mutate({ cartId, quantity });
  };

  const handleRemoveItem = (cartId: string) => {
    removeItemMutation.mutate(cartId);
  };

  const handleCheckout = () => {
    checkoutMutation.mutate(total);
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {[...Array(2)].map((_, i) => (
                <div key={i} className="bg-muted rounded-xl h-32"></div>
              ))}
            </div>
            <div className="bg-muted rounded-xl h-64"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <h1 className="text-2xl font-bold text-foreground">Shopping Cart</h1>
        <span className="ml-3 text-muted-foreground">
          (<span data-testid="text-cart-count">{cartItems.length}</span> items)
        </span>
      </div>

      {cartItems.length > 0 ? (
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            {cartItems.map((item) => (
              <Card key={item.id} className="shadow-sm" data-testid={`cart-item-${item.id}`}>
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
                    {/* Product Image */}
                    <div className="w-full sm:w-24 h-24 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                      {item.product.image ? (
                        <img 
                          src={item.product.image} 
                          alt={item.product.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-muted-foreground">No image</div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1" data-testid={`text-item-title-${item.id}`}>
                        {item.product.title}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-2">
                        Sold by {item.product.ownerId}
                      </p>
                      <div className="flex items-center space-x-4">
                        <Badge variant="secondary" className="text-xs">
                          {item.product.condition} condition
                        </Badge>
                        <span className="text-sm text-muted-foreground capitalize">
                          {item.product.category}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:block space-x-4 sm:space-x-0">
                      <div className="flex items-center space-x-3">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1 || updateQuantityMutation.isPending}
                          data-testid={`button-decrease-${item.id}`}
                          className="h-8 w-8 p-0"
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="font-semibold w-8 text-center" data-testid={`text-quantity-${item.id}`}>
                          {item.quantity}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          disabled={updateQuantityMutation.isPending}
                          data-testid={`button-increase-${item.id}`}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="text-right mt-2">
                        <p className="text-lg font-bold text-primary" data-testid={`text-item-total-${item.id}`}>
                          ${(parseFloat(item.product.price) * item.quantity).toFixed(2)}
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveItem(item.id)}
                          disabled={removeItemMutation.isPending}
                          data-testid={`button-remove-${item.id}`}
                          className="text-destructive hover:text-destructive text-xs mt-1 h-6 px-2"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Continue Shopping */}
            <div className="text-center py-6">
              <Link href="/feed">
                <Button variant="ghost" data-testid="button-continue-shopping">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Continue Shopping
                </Button>
              </Link>
            </div>
          </div>

          {/* Order Summary */}
          <Card className="shadow-sm h-fit">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold text-foreground mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal ({cartItems.length} items)</span>
                  <span className="font-semibold" data-testid="text-subtotal">
                    ${subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-semibold text-secondary">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax estimate</span>
                  <span className="font-semibold" data-testid="text-tax">
                    ${tax.toFixed(2)}
                  </span>
                </div>
                <div className="border-t border-border pt-4">
                  <div className="flex justify-between">
                    <span className="text-lg font-semibold text-foreground">Total</span>
                    <span className="text-lg font-bold text-primary" data-testid="text-total">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Savings */}
              <div className="bg-green-50 p-4 rounded-lg mb-6">
                <div className="flex items-center mb-2">
                  <DollarSign className="h-4 w-4 text-green-600 mr-2" />
                  <span className="text-sm font-semibold text-green-600">You're Saving</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  You saved <strong>$45.00</strong> by shopping smart with us!
                </p>
              </div>

              {/* Payment Method */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-3">Payment Method</label>
                <Select defaultValue="card">
                  <SelectTrigger data-testid="select-payment-method">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="card">Credit/Debit Card</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Checkout Button */}
              <Button
                onClick={handleCheckout}
                disabled={checkoutMutation.isPending}
                className="w-full text-lg py-6 mb-4"
                data-testid="button-checkout"
              >
                {checkoutMutation.isPending ? (
                  "Processing..."
                ) : (
                  <>
                    <Lock className="h-4 w-4 mr-2" />
                    Secure Checkout
                  </>
                )}
              </Button>

              <div className="text-center text-xs text-muted-foreground">
                <ShieldCheck className="h-3 w-3 inline mr-1" />
                Your payment information is secure
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="text-center py-16" data-testid="empty-cart">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-muted text-muted-foreground rounded-xl mb-4">
            <ShoppingCart className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">Your cart is empty</h3>
          <p className="text-muted-foreground mb-6">Discover amazing sustainable finds in our marketplace</p>
          <Link href="/feed">
            <Button data-testid="button-browse-items">
              Browse Items
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
