import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Plus, CloudUpload } from "lucide-react";

const productSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Category is required"),
  price: z.string().min(1, "Price is required").refine((val) => !isNaN(Number(val)) && Number(val) > 0, "Price must be a positive number"),
  condition: z.string().default("good"),
  delivery: z.string().default("pickup"),
  image: z.string().optional(),
});

type ProductFormData = z.infer<typeof productSchema>;

export default function AddProduct() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      price: "",
      condition: "good",
      delivery: "pickup",
      image: "",
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: ProductFormData) => {
      const response = await apiRequest("POST", "/api/products", {
        ...data,
        price: data.price.toString(),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user', user?.id, 'products'] });
      toast({
        title: "Item listed successfully!",
        description: "Your item is now available in the marketplace.",
      });
      setLocation("/my-listings");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to list item",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProductFormData) => {
    createProductMutation.mutate(data);
  };

  const categories = [
    { value: "electronics", label: "Electronics" },
    { value: "clothing", label: "Clothing & Accessories" },
    { value: "home", label: "Home & Garden" },
    { value: "books", label: "Books & Media" },
    { value: "sports", label: "Sports & Recreation" },
    { value: "other", label: "Other" },
  ];

  const conditions = [
    { value: "excellent", label: "Like New" },
    { value: "good", label: "Good" },
    { value: "fair", label: "Fair" },
    { value: "poor", label: "Needs Work" },
  ];

  const deliveryOptions = [
    { value: "pickup", label: "Local Pickup" },
    { value: "shipping", label: "Can Ship" },
    { value: "both", label: "Both Options" },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Card className="shadow-sm">
        <CardHeader className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 text-primary rounded-xl mb-4 mx-auto">
            <Plus className="h-6 w-6" />
          </div>
          <CardTitle>List Your Item</CardTitle>
          <CardDescription>Share your sustainable treasures with the community</CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            {/* Image Upload Section */}
            <div>
              <Label className="text-base font-medium mb-4 block">Product Images</Label>
              <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary transition-colors cursor-pointer">
                <CloudUpload className="h-12 w-12 text-muted-foreground mb-4 mx-auto" />
                <p className="text-foreground font-semibold mb-2">
                  Drop your images here, or <span className="text-primary">browse</span>
                </p>
                <p className="text-muted-foreground text-sm">Support: JPG, PNG up to 5MB each</p>
                <Input
                  type="url"
                  placeholder="Or paste image URL"
                  data-testid="input-image-url"
                  {...form.register("image")}
                  className="mt-4 max-w-md mx-auto"
                />
              </div>
            </div>

            {/* Basic Information */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="title">Item Title *</Label>
                <Input
                  id="title"
                  placeholder="e.g., Vintage Leather Jacket"
                  data-testid="input-title"
                  {...form.register("title")}
                  className="mt-1"
                />
                {form.formState.errors.title && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.title.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={form.watch("category")}
                  onValueChange={(value) => form.setValue("category", value)}
                >
                  <SelectTrigger className="mt-1" data-testid="select-category">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.category && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.category.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                rows={5}
                placeholder="Describe your item's condition, features, and why it's special..."
                data-testid="textarea-description"
                {...form.register("description")}
                className="mt-1"
              />
              {form.formState.errors.description && (
                <p className="text-sm text-destructive mt-1">
                  {form.formState.errors.description.message}
                </p>
              )}
            </div>

            {/* Price and Condition */}
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="price">Price *</Label>
                <div className="relative mt-1">
                  <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground">$</span>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    data-testid="input-price"
                    {...form.register("price")}
                    className="pl-8"
                  />
                </div>
                {form.formState.errors.price && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.price.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="condition">Condition</Label>
                <Select
                  value={form.watch("condition")}
                  onValueChange={(value) => form.setValue("condition", value)}
                >
                  <SelectTrigger className="mt-1" data-testid="select-condition">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {conditions.map((condition) => (
                      <SelectItem key={condition.value} value={condition.value}>
                        {condition.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="delivery">Delivery</Label>
                <Select
                  value={form.watch("delivery")}
                  onValueChange={(value) => form.setValue("delivery", value)}
                >
                  <SelectTrigger className="mt-1" data-testid="select-delivery">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {deliveryOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Sustainability Features */}
            <div>
              <Label className="text-base font-medium mb-4 block">Sustainability Features</Label>
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  "Recycled Materials",
                  "Eco-Friendly Packaging", 
                  "Locally Sourced",
                  "Energy Efficient",
                ].map((feature) => (
                  <div key={feature} className="flex items-center space-x-3">
                    <Checkbox id={feature.toLowerCase().replace(' ', '-')} />
                    <Label
                      htmlFor={feature.toLowerCase().replace(' ', '-')}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {feature}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-6 border-t border-border">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/feed")}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createProductMutation.isPending}
                data-testid="button-list-item"
              >
                {createProductMutation.isPending ? (
                  "Listing Item..."
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    List Item
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
