import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  ShoppingCart, 
  Share, 
  Flag, 
  User, 
  Star, 
  Clock, 
  Truck,
  Package,
  Undo,
  Leaf,
  Recycle,
  ShieldCheck 
} from "lucide-react";
import type { ProductWithOwner } from "@shared/schema";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id;
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery<ProductWithOwner>({
    queryKey: ['/api/products', productId],
    enabled: !!productId,
  });

  // Get similar products
  const { data: similarProducts = [] } = useQuery<ProductWithOwner[]>({
    queryKey: ['/api/products', { category: product?.category }],
    enabled: !!product?.category,
  });

  // Check if product is favorited
  const { data: favoriteStatus = { isFavorite: false } } = useQuery<{ isFavorite: boolean }>({
    queryKey: ['/api/favorites', productId],
    enabled: !!user && !!productId,
  });

  const addToCartMutation = useMutation({
    mutationFn: async (productId: string) => {
      const response = await apiRequest("POST", "/api/cart/add", {
        productId,
        quantity: 1,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Added to cart!",
        description: "Item has been added to your cart.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add to cart",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      if (favoriteStatus.isFavorite) {
        await apiRequest("DELETE", `/api/favorites/${productId}`, {});
        return false;
      } else {
        await apiRequest("POST", "/api/favorites", { productId });
        return true;
      }
    },
    onSuccess: (newFavoriteState) => {
      queryClient.invalidateQueries({ queryKey: ['/api/favorites', productId] });
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
      toast({
        title: newFavoriteState ? "Added to favorites!" : "Removed from favorites",
        description: newFavoriteState 
          ? "Product added to your favorites." 
          : "Product removed from your favorites.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddToCart = () => {
    if (product) {
      addToCartMutation.mutate(product.id);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product?.title,
          text: product?.description,
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Product link has been copied to clipboard.",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="animate-pulse grid lg:grid-cols-2 gap-12">
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-xl"></div>
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <div className="h-8 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-16 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold text-foreground mb-2">Product not found</h1>
        <p className="text-muted-foreground">The product you're looking for doesn't exist.</p>
      </div>
    );
  }

  const filteredSimilarProducts = similarProducts
    .filter(p => p.id !== product.id)
    .slice(0, 3);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="grid lg:grid-cols-2 gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square bg-muted rounded-xl overflow-hidden">
            {product.image ? (
              <img 
                src={product.image} 
                alt={product.title}
                className="w-full h-full object-cover"
                data-testid="img-product-main"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Package className="h-16 w-16 text-muted-foreground" />
              </div>
            )}
          </div>
        </div>

        {/* Product Information */}
        <div className="space-y-8">
          {/* Header */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <Badge variant="secondary" className="mb-2">
                {product.category}
              </Badge>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => toggleFavoriteMutation.mutate()}
                disabled={!user || toggleFavoriteMutation.isPending}
                data-testid="button-favorite-header"
              >
                <Heart className={`h-5 w-5 ${favoriteStatus.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
              </Button>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-product-title">
              {product.title}
            </h1>
            <p className="text-4xl font-bold text-primary mb-4" data-testid="text-product-price">
              ${product.price}
            </p>
            
            {/* Seller Info */}
            <Card className="p-4 bg-muted">
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <User className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground" data-testid="text-seller-name">
                    {product.owner.username}
                  </h4>
                  <div className="flex items-center space-x-3 text-sm text-muted-foreground">
                    <span><Star className="h-3 w-3 text-yellow-500 inline mr-1" />{product.owner.rating || "4.5"} ({product.owner.ratingCount || 0} reviews)</span>
                    <span><Clock className="h-3 w-3 inline mr-1" />Usually responds within 2 hours</span>
                  </div>
                  {product.owner.phone && (
                    <div className="flex items-center text-sm text-muted-foreground mt-1">
                      <span>📞 {product.owner.phone}</span>
                    </div>
                  )}
                  {product.owner.email && (
                    <div className="flex items-center text-sm text-muted-foreground mt-1">
                      <span>✉️ {product.owner.email}</span>
                    </div>
                  )}
                </div>
                <Button size="sm" data-testid="button-contact-seller">
                  Contact Seller
                </Button>
              </div>
            </Card>
          </div>

          {/* Product Details */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">Description</h3>
            <p className="text-foreground leading-relaxed mb-6" data-testid="text-product-description">
              {product.description}
            </p>

            {/* Product Specifications */}
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-foreground mb-3">Specifications</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Condition:</span>
                    <span className="font-medium capitalize">{product.condition}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Category:</span>
                    <span className="font-medium capitalize">{product.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Delivery:</span>
                    <span className="font-medium capitalize">{product.delivery}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Listed:</span>
                    <span className="font-medium">{new Date(product.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-foreground mb-3">Eco Features</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Leaf className="h-3 w-3 text-primary mr-2" />
                    <span>Sustainable Fashion</span>
                  </div>
                  <div className="flex items-center">
                    <Recycle className="h-3 w-3 text-primary mr-2" />
                    <span>Pre-loved Item</span>
                  </div>
                  <div className="flex items-center">
                    <Truck className="h-3 w-3 text-primary mr-2" />
                    <span>Local Pickup Available</span>
                  </div>
                  <div className="flex items-center">
                    <ShieldCheck className="h-3 w-3 text-accent mr-2" />
                    <span>Quality Verified</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <Button 
              onClick={handleAddToCart}
              disabled={addToCartMutation.isPending || product.ownerId === user?.id}
              className="w-full text-lg py-6"
              data-testid="button-add-to-cart"
            >
              {product.ownerId === user?.id ? (
                "This is your item"
              ) : addToCartMutation.isPending ? (
                "Adding to Cart..."
              ) : (
                <>
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </>
              )}
            </Button>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="secondary" onClick={handleShare} data-testid="button-share">
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>
              <Button variant="secondary" data-testid="button-report">
                <Flag className="h-4 w-4 mr-2" />
                Report
              </Button>
            </div>
          </div>

          {/* Delivery Information */}
          <Card className="bg-muted p-6">
            <h4 className="font-semibold text-foreground mb-4">Delivery & Returns</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center">
                <Truck className="h-4 w-4 text-primary mr-3" />
                <span><strong>Free local pickup</strong> - Available within 10 miles</span>
              </div>
              <div className="flex items-center">
                <Package className="h-4 w-4 text-primary mr-3" />
                <span><strong>Shipping available</strong> - $12.99 via sustainable packaging</span>
              </div>
              <div className="flex items-center">
                <Undo className="h-4 w-4 text-primary mr-3" />
                <span><strong>3-day return policy</strong> - If item doesn't match description</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Similar Items Section */}
      {filteredSimilarProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-foreground mb-8">Similar Items</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {filteredSimilarProducts.map((similarProduct) => (
              <Card key={similarProduct.id} className="overflow-hidden hover:shadow-lg transition-all cursor-pointer">
                <div className="aspect-video bg-muted flex items-center justify-center">
                  {similarProduct.image ? (
                    <img 
                      src={similarProduct.image} 
                      alt={similarProduct.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Package className="h-8 w-8 text-muted-foreground" />
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-foreground mb-2 line-clamp-1">
                    {similarProduct.title}
                  </h3>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-primary">
                      ${similarProduct.price}
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {similarProduct.category}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
