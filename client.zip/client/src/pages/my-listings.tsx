import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Eye, Package } from "lucide-react";
import type { Product } from "@shared/schema";

export default function MyListings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: listings = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/user', user?.id, 'products'],
    enabled: !!user?.id,
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (productId: string) => {
      const response = await apiRequest("DELETE", `/api/products/${productId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user', user?.id, 'products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Item deleted",
        description: "Your item has been removed successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Delete failed",
        description: error.message || "Failed to delete item.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (productId: string, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"? This action cannot be undone.`)) {
      deleteProductMutation.mutate(productId);
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-muted rounded-xl h-32"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground">My Listings</h1>
          <p className="text-muted-foreground mt-1">Manage your sustainable marketplace items</p>
        </div>
        <Link href="/add-product">
          <Button data-testid="button-add-new-item">
            <Plus className="h-4 w-4 mr-2" />
            Add New Item
          </Button>
        </Link>
      </div>

      {listings.length > 0 ? (
        <div className="space-y-6">
          {listings.map((listing) => (
            <Card key={listing.id} className="shadow-sm hover:shadow-md transition-all" data-testid={`card-listing-${listing.id}`}>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
                  {/* Product Image */}
                  <div className="w-full lg:w-32 h-32 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                    {listing.image ? (
                      <img 
                        src={listing.image} 
                        alt={listing.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Package className="h-8 w-8 text-muted-foreground" />
                    )}
                  </div>
                  
                  {/* Product Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-lg font-semibold text-foreground" data-testid={`text-listing-title-${listing.id}`}>
                        {listing.title}
                      </h3>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={listing.isActive ? "default" : "secondary"}
                          className={listing.isActive ? "bg-primary/10 text-primary" : ""}
                        >
                          {listing.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <span className="text-lg font-bold text-primary" data-testid={`text-listing-price-${listing.id}`}>
                          ${listing.price}
                        </span>
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {listing.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <span className="capitalize">{listing.category}</span>
                        <span className="capitalize">{listing.condition} condition</span>
                        <span>{new Date(listing.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center space-x-2">
                    <Link href={`/product/${listing.id}`}>
                      <Button variant="ghost" size="sm" data-testid={`button-view-${listing.id}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </Link>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        // TODO: Implement edit functionality
                        toast({
                          title: "Edit functionality",
                          description: "Product editing will be available soon.",
                        });
                      }}
                      data-testid={`button-edit-${listing.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDelete(listing.id, listing.title)}
                      disabled={deleteProductMutation.isPending}
                      data-testid={`button-delete-${listing.id}`}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-16" data-testid="empty-listings">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-muted text-muted-foreground rounded-xl mb-4">
            <Package className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No listings yet</h3>
          <p className="text-muted-foreground mb-6">Start sharing your sustainable items with the community</p>
          <Link href="/add-product">
            <Button data-testid="button-create-first-listing">
              <Plus className="h-4 w-4 mr-2" />
              Create First Listing
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
