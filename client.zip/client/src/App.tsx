import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "./hooks/use-auth";
import Navigation from "./components/navigation";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import ProductFeed from "@/pages/product-feed";
import AddProduct from "@/pages/add-product";
import MyListings from "@/pages/my-listings";
import ProductDetail from "@/pages/product-detail";
import Cart from "@/pages/cart";
import Purchases from "@/pages/purchases";
import Favorites from "@/pages/favorites";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <>
      <Navigation />
      <main className="min-h-screen">{children}</main>
    </>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={() => <ProtectedRoute><ProductFeed /></ProtectedRoute>} />
      <Route path="/feed" component={() => <ProtectedRoute><ProductFeed /></ProtectedRoute>} />
      <Route path="/dashboard" component={() => <ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/add-product" component={() => <ProtectedRoute><AddProduct /></ProtectedRoute>} />
      <Route path="/my-listings" component={() => <ProtectedRoute><MyListings /></ProtectedRoute>} />
      <Route path="/product/:id" component={() => <ProtectedRoute><ProductDetail /></ProtectedRoute>} />
      <Route path="/cart" component={() => <ProtectedRoute><Cart /></ProtectedRoute>} />
      <Route path="/favorites" component={() => <ProtectedRoute><Favorites /></ProtectedRoute>} />
      <Route path="/purchases" component={() => <ProtectedRoute><Purchases /></ProtectedRoute>} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
