import { apiRequest } from "./queryClient";
import type { User, InsertUser } from "@shared/schema";

export interface AuthResponse {
  user: User;
  token: string;
  message: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface RegisterData extends InsertUser {}

export async function login(data: LoginData): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/login", data);
  const result = await response.json();
  
  // Store token in localStorage
  if (result.token) {
    localStorage.setItem("auth_token", result.token);
  }
  
  return result;
}

export async function register(data: RegisterData): Promise<AuthResponse> {
  const response = await apiRequest("POST", "/api/auth/register", data);
  const result = await response.json();
  
  // Store token in localStorage
  if (result.token) {
    localStorage.setItem("auth_token", result.token);
  }
  
  return result;
}

export function logout(): void {
  localStorage.removeItem("auth_token");
  localStorage.removeItem("user_data");
}

export function getAuthToken(): string | null {
  return localStorage.getItem("auth_token");
}

export function setUserData(user: User): void {
  localStorage.setItem("user_data", JSON.stringify(user));
}

export function getUserData(): User | null {
  const userData = localStorage.getItem("user_data");
  return userData ? JSON.parse(userData) : null;
}
