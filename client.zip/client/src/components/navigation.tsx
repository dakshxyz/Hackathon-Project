import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Leaf, ShoppingCart, User, Menu, X, Plus, Heart, Bell, MessageCircle } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { CartWithProduct } from "@shared/schema";

export default function Navigation() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Get cart count
  const { data: cartItems = [] } = useQuery<CartWithProduct[]>({
    queryKey: ['/api/cart'],
    enabled: isAuthenticated,
  });

  const cartCount = cartItems.length;

  const navigation = [
    { name: 'Browse', href: '/feed', icon: ShoppingCart },
    { name: 'My Listings', href: '/my-listings', icon: User },
    { name: 'Orders', href: '/purchases', icon: ShoppingCart },
  ];

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* Main Navigation */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/feed" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
              <div className="bg-primary text-white p-2 rounded-xl">
                <ShoppingCart className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-primary">MarketPlace</h1>
              </div>
            </Link>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center space-x-4">
              <Link href="/add-product">
                <Button className="bg-primary hover:bg-primary/90" data-testid="button-sell-now">
                  <Plus className="h-4 w-4 mr-2" />
                  Sell Now
                </Button>
              </Link>
              
              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs bg-red-500 text-white">
                  3
                </Badge>
              </Button>
              
              {/* Messages */}
              <Button variant="ghost" size="sm">
                <MessageCircle className="h-5 w-5" />
              </Button>

              {/* Favorites */}
              <Link href="/favorites">
                <Button variant="ghost" size="sm" data-testid="button-favorites">
                  <Heart className="h-5 w-5" />
                </Button>
              </Link>

              {/* Cart */}
              <Link href="/cart">
                <Button variant="ghost" size="sm" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {cartCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs bg-primary text-white">
                      {cartCount}
                    </Badge>
                  )}
                </Button>
              </Link>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 hover:bg-gray-100">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-white">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium max-w-[100px] truncate">{user?.username}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem>
                    <Link href="/dashboard" className="flex items-center w-full">
                      <User className="h-4 w-4 mr-3" />
                      My Account
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/my-listings" className="flex items-center w-full">
                      <Plus className="h-4 w-4 mr-3" />
                      My Listings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/purchases" className="flex items-center w-full">
                      <ShoppingCart className="h-4 w-4 mr-3" />
                      My Orders
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/favorites" className="flex items-center w-full">
                      <Heart className="h-4 w-4 mr-3" />
                      Favorites
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-red-600">
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-3">
              <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-gray-200">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-primary text-white">
                    <User className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{user?.username}</p>
                  <p className="text-sm text-gray-500">View Profile</p>
                </div>
              </div>
              
              <div className="space-y-1">
                <Link href="/add-product">
                  <div className="flex items-center space-x-3 py-3 hover:bg-gray-50 rounded-lg px-2" onClick={() => setMobileMenuOpen(false)}>
                    <Plus className="h-5 w-5 text-primary" />
                    <span className="font-medium">Sell Item</span>
                  </div>
                </Link>
                
                {navigation.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <div className="flex items-center space-x-3 py-3 hover:bg-gray-50 rounded-lg px-2" onClick={() => setMobileMenuOpen(false)}>
                      <item.icon className="h-5 w-5 text-gray-600" />
                      <span>{item.name}</span>
                    </div>
                  </Link>
                ))}
                
                <Link href="/cart">
                  <div className="flex items-center justify-between py-3 hover:bg-gray-50 rounded-lg px-2" onClick={() => setMobileMenuOpen(false)}>
                    <div className="flex items-center space-x-3">
                      <ShoppingCart className="h-5 w-5 text-gray-600" />
                      <span>Cart</span>
                    </div>
                    {cartCount > 0 && (
                      <Badge className="bg-primary text-white">{cartCount}</Badge>
                    )}
                  </div>
                </Link>
                
                <div className="pt-4 border-t border-gray-200 mt-4">
                  <button
                    onClick={() => {
                      logout();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-left py-3 text-red-600 hover:bg-red-50 rounded-lg px-2"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
