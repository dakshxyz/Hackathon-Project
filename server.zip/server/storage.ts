import { users, products, cart, orders, orderItems, favorites, ratings, type User, type InsertUser, type Product, type InsertProduct, type ProductWithOwner, type Cart, type CartWithProduct, type InsertCart, type Order, type OrderWithItems, type InsertOrder, type Favorite, type FavoriteWithProduct, type InsertFavorite, type Rating, type RatingWithUser, type InsertRating } from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, and, avg, count } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;

  // Product operations
  getProducts(search?: string, category?: string): Promise<ProductWithOwner[]>;
  getProduct(id: string): Promise<ProductWithOwner | undefined>;
  getUserProducts(userId: string): Promise<Product[]>;
  createProduct(product: InsertProduct & { ownerId: string }): Promise<Product>;
  updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: string): Promise<void>;

  // Cart operations
  getCart(userId: string): Promise<CartWithProduct[]>;
  addToCart(userId: string, cartItem: InsertCart): Promise<Cart>;
  updateCartItem(cartId: string, quantity: number): Promise<Cart>;
  removeFromCart(cartId: string): Promise<void>;
  clearCart(userId: string): Promise<void>;

  // Order operations
  createOrder(userId: string, orderData: InsertOrder, items: Array<{ productId: string; quantity: number; price: string }>): Promise<Order>;
  getOrders(userId: string): Promise<OrderWithItems[]>;
  getOrder(orderId: string): Promise<OrderWithItems | undefined>;

  // Favorites operations
  getFavorites(userId: string): Promise<FavoriteWithProduct[]>;
  addFavorite(userId: string, productId: string): Promise<Favorite>;
  removeFavorite(userId: string, productId: string): Promise<void>;
  isFavorite(userId: string, productId: string): Promise<boolean>;

  // Rating operations
  createRating(raterId: string, ratingData: InsertRating): Promise<Rating>;
  getUserRatings(userId: string): Promise<RatingWithUser[]>;
  updateUserRating(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Product operations
  async getProducts(search?: string, category?: string): Promise<ProductWithOwner[]> {
    // Build where conditions
    const whereConditions = [eq(products.isActive, true)];
    
    if (search) {
      whereConditions.push(like(products.title, `%${search}%`));
    }
    
    if (category) {
      whereConditions.push(eq(products.category, category));
    }

    const result = await db
      .select({
        id: products.id,
        title: products.title,
        description: products.description,
        category: products.category,
        price: products.price,
        condition: products.condition,
        delivery: products.delivery,
        image: products.image,
        ownerId: products.ownerId,
        isActive: products.isActive,
        createdAt: products.createdAt,
        owner: {
          id: users.id,
          username: users.username,
          email: users.email,
          password: users.password,
          bio: users.bio,
          createdAt: users.createdAt,
        }
      })
      .from(products)
      .leftJoin(users, eq(products.ownerId, users.id))
      .where(and(...whereConditions))
      .orderBy(desc(products.createdAt));

    return result.map(row => ({
      ...row,
      owner: row.owner!
    }));
  }

  async getProduct(id: string): Promise<ProductWithOwner | undefined> {
    const [result] = await db
      .select({
        id: products.id,
        title: products.title,
        description: products.description,
        category: products.category,
        price: products.price,
        condition: products.condition,
        delivery: products.delivery,
        image: products.image,
        ownerId: products.ownerId,
        isActive: products.isActive,
        createdAt: products.createdAt,
        owner: {
          id: users.id,
          username: users.username,
          email: users.email,
          password: users.password,
          bio: users.bio,
          createdAt: users.createdAt,
        }
      })
      .from(products)
      .leftJoin(users, eq(products.ownerId, users.id))
      .where(eq(products.id, id));

    if (!result || !result.owner) return undefined;
    
    return {
      ...result,
      owner: result.owner
    };
  }

  async getUserProducts(userId: string): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.ownerId, userId))
      .orderBy(desc(products.createdAt));
  }

  async createProduct(productData: InsertProduct & { ownerId: string }): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(productData)
      .returning();
    return product;
  }

  async updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product> {
    const [product] = await db
      .update(products)
      .set(updates)
      .where(eq(products.id, id))
      .returning();
    return product;
  }

  async deleteProduct(id: string): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Cart operations
  async getCart(userId: string): Promise<CartWithProduct[]> {
    const result = await db
      .select({
        id: cart.id,
        userId: cart.userId,
        productId: cart.productId,
        quantity: cart.quantity,
        createdAt: cart.createdAt,
        product: {
          id: products.id,
          title: products.title,
          description: products.description,
          category: products.category,
          price: products.price,
          condition: products.condition,
          delivery: products.delivery,
          image: products.image,
          ownerId: products.ownerId,
          isActive: products.isActive,
          createdAt: products.createdAt,
        }
      })
      .from(cart)
      .leftJoin(products, eq(cart.productId, products.id))
      .where(eq(cart.userId, userId));

    return result.map(row => ({
      ...row,
      product: row.product!
    }));
  }

  async addToCart(userId: string, cartItem: InsertCart): Promise<Cart> {
    const [newCartItem] = await db
      .insert(cart)
      .values({ ...cartItem, userId })
      .returning();
    return newCartItem;
  }

  async updateCartItem(cartId: string, quantity: number): Promise<Cart> {
    const [updated] = await db
      .update(cart)
      .set({ quantity })
      .where(eq(cart.id, cartId))
      .returning();
    return updated;
  }

  async removeFromCart(cartId: string): Promise<void> {
    await db.delete(cart).where(eq(cart.id, cartId));
  }

  async clearCart(userId: string): Promise<void> {
    await db.delete(cart).where(eq(cart.userId, userId));
  }

  // Order operations
  async createOrder(userId: string, orderData: InsertOrder, items: Array<{ productId: string; quantity: number; price: string }>): Promise<Order> {
    return await db.transaction(async (tx) => {
      const [order] = await tx
        .insert(orders)
        .values({ ...orderData, userId })
        .returning();

      for (const item of items) {
        await tx.insert(orderItems).values({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
        });
      }

      return order;
    });
  }

  async getOrders(userId: string): Promise<OrderWithItems[]> {
    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));

    const result: OrderWithItems[] = [];

    for (const order of userOrders) {
      const items = await db
        .select({
          id: orderItems.id,
          orderId: orderItems.orderId,
          productId: orderItems.productId,
          quantity: orderItems.quantity,
          price: orderItems.price,
          product: {
            id: products.id,
            title: products.title,
            description: products.description,
            category: products.category,
            price: products.price,
            condition: products.condition,
            delivery: products.delivery,
            image: products.image,
            ownerId: products.ownerId,
            isActive: products.isActive,
            createdAt: products.createdAt,
          }
        })
        .from(orderItems)
        .leftJoin(products, eq(orderItems.productId, products.id))
        .where(eq(orderItems.orderId, order.id));

      result.push({
        ...order,
        items: items.map(item => ({
          ...item,
          product: item.product!
        }))
      });
    }

    return result;
  }

  async getOrder(orderId: string): Promise<OrderWithItems | undefined> {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId));

    if (!order) return undefined;

    const items = await db
      .select({
        id: orderItems.id,
        orderId: orderItems.orderId,
        productId: orderItems.productId,
        quantity: orderItems.quantity,
        price: orderItems.price,
        product: {
          id: products.id,
          title: products.title,
          description: products.description,
          category: products.category,
          price: products.price,
          condition: products.condition,
          delivery: products.delivery,
          image: products.image,
          ownerId: products.ownerId,
          isActive: products.isActive,
          createdAt: products.createdAt,
        }
      })
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, orderId));

    return {
      ...order,
      items: items.map(item => ({
        ...item,
        product: item.product!
      }))
    };
  }
  
  // Favorites operations
  async getFavorites(userId: string): Promise<FavoriteWithProduct[]> {
    const userFavorites = await db.query.favorites.findMany({
      where: eq(favorites.userId, userId),
      with: {
        product: {
          with: {
            owner: true,
          },
        },
      },
      orderBy: desc(favorites.createdAt),
    });

    return userFavorites;
  }

  async addFavorite(userId: string, productId: string): Promise<Favorite> {
    const [favorite] = await db
      .insert(favorites)
      .values({ userId, productId })
      .returning();
    return favorite;
  }

  async removeFavorite(userId: string, productId: string): Promise<void> {
    await db
      .delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.productId, productId)));
  }

  async isFavorite(userId: string, productId: string): Promise<boolean> {
    const favorite = await db.query.favorites.findFirst({
      where: and(eq(favorites.userId, userId), eq(favorites.productId, productId)),
    });
    return !!favorite;
  }

  // Rating operations
  async createRating(raterId: string, ratingData: InsertRating): Promise<Rating> {
    const [rating] = await db
      .insert(ratings)
      .values({ ...ratingData, raterId })
      .returning();
    
    // Update the ratee's average rating
    await this.updateUserRating(ratingData.rateeId);
    
    return rating;
  }

  async getUserRatings(userId: string): Promise<RatingWithUser[]> {
    const userRatings = await db.query.ratings.findMany({
      where: eq(ratings.rateeId, userId),
      with: {
        rater: true,
      },
      orderBy: desc(ratings.createdAt),
    });

    return userRatings;
  }

  async updateUserRating(userId: string): Promise<void> {
    // Calculate average rating and count
    const result = await db
      .select({
        avgRating: avg(ratings.rating),
        count: count(ratings.id),
      })
      .from(ratings)
      .where(eq(ratings.rateeId, userId));

    const { avgRating, count: ratingCount } = result[0];
    
    // Update user's rating fields
    await db
      .update(users)
      .set({
        rating: avgRating ? Number(avgRating).toFixed(2) : "4.5",
        ratingCount: Number(ratingCount),
      })
      .where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();
